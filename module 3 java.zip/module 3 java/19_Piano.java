public class Piano implements Playable {
    public void play() {
        System.out.println("Playing the piano");
    }
}
