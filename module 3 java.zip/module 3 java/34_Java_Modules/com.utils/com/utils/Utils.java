package com.utils;

public class Utils {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
}