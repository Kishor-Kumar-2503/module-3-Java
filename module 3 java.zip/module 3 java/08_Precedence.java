public class Precedence {
    public static void main(String[] args) {
        int result = 10 + 5 * 2;
        System.out.println("Result of 10 + 5 * 2 = " + result);
        // Multiplication done first, so 5*2=10, then 10+10=20
    }
}
