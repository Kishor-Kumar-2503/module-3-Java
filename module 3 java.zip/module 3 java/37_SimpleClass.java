public class SimpleClass {
    public void sayHello() {
        System.out.println("Hello Bytecode!");
    }
}