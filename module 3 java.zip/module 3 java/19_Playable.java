public interface Playable {
    void play();
}
